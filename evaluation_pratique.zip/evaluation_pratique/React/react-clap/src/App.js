import './App.css';
import Clapcount from './Clap/Clapcount';



function App() {


  return (
    <Clapcount
      start = {0}
      
    />
  );
}

export default App;
