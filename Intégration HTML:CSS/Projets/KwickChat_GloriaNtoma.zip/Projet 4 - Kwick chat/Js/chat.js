Window.location.href = "chat.html";
