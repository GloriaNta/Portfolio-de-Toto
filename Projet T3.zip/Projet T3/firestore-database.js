import config from './config.js';

// Initialisation de Firebase
firebase.initializeApp(config);