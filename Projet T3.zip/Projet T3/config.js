export default{
    apiKey: "AIzaSyDE8JBFvbFVURWvgT-TpY2TXO2pcXZuAUM",
    authDomain: "linx-16e98.firebaseapp.com",
    projectId: "linx-16e98",
    storageBucket: "linx-16e98.appspot.com",
    messagingSenderId: "685064052772",
    appId: "1:685064052772:web:6a8809e4c7c464da4778b1",
    measurementId: "G-1Z2D863282"
};